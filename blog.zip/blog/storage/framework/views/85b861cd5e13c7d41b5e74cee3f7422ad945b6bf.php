<h1>Am from hello page</h1>  



<ul>
    <?php $__currentLoopData = $_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo $name; ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</ul>

<?php 
//normal php way
foreach ($_names as $name){
    echo $name ."<br>";
}
unset($name);
?>