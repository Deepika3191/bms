<h1>Am from hello page</h1>  



<ul>
    @foreach($_names as $name)
    <li>{!! $name !!}</li>
    @endforeach
    
</ul>

<?php 
//normal php way
foreach ($_names as $name){
    echo $name ."<br>";
}
unset($name);
?>