<?php
 namespace App\Helpers;

trait MobileApi{
     
     function test(){
         return "am from triti";
     }
}