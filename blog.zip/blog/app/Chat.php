<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Chat extends Model
{
    public $table = 'chats';
    public $timestamps = false;
    protected $primaryKey = 'id';
    public $fillable = [
        'vendorid',
        'organizerid',
        'eventid',
        'reqstatus'
    ];
}
