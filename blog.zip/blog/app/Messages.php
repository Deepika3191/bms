<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Messages extends Model
{
    public $table = 'messages';
    public $timestamps = false;
    protected $primaryKey = 'id';
    public $fillable = [
        'chatid',
        'senderid',
        'receiverid',
        'message'
    ];
}
