<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Events extends Model
{
    public $table = 'events';
    public $timestamps = false;
    protected $primaryKey = 'id';
    public $fillable = [
        'name',
        'eventmanager_id'
    ];
}
