<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Notification;


use App\Chat;
use App\Messages;
use App\Events;
use http\Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;


class ChatController extends Controller
{

    /*public function index(Request $request){
            return $request->all();
     */
    public function testNoti(Notification $noti){
        return $noti->notiTest();
    }
    public function sendMessage(Request $request){
        $input = $request->all();
        $chatid = $input['chatid'];
	$senderid = $input['senderid'];
	$receiverid = $input['receiverid'];
	$message = $input['message'];
        Messages::insert(
            [   'chatid' => $chatid,
                'senderid' => $senderid,
                'receiverid' => $receiverid, 
                'message' => $message
                ]
	);
        $msg_id = DB::getPdo()->lastInsertId();
        if ($msg_id > 0) {
            return response()->json(['success' => true, 'message' => "Message added successfully", "code" => 200, "msg_id" => $msg_id], 200);
        }
        else{
            return response()->json(['success' => true, 'message' => "Message not sent", "code" => 400], 400);
        }
    }
    /**
    * @param $userId
    * @return \Illuminate\Http\JsonResponse
    */
   public function getMessages($userid, $chatid) {
        $message_data = array();
        if ($userid) {
            /*Getting required data*/
            $message_data = Messages::where("senderid", $userid)->where("chatid", $chatid)->orwhere("receiverid", $userid)->orderby('timestamp')->get();
            if (count($message_data)) {
                foreach ($message_data as $msg) {
                    $temp = array(
                        'id' => $msg['id'],
                        'senderid' => $msg['senderid'],
                        'receiverid' => $msg['receiverid'],
                        'timestamp' => $msg['timestamp']
                    );
                    $return_data[] = $temp;
                }
                 unset($msg);
                 return response()->json(['success' => true, 'message' => "Messages", "code" => 200, "data" => $return_data], 200);
            }
            else{
                 return response()->json(['success' => false, 'message' => "no messages", "code" => 400], 400);
           }
        }
        else{
            return response()->json(['success' => false, 'message' => "no input", "code" => 400], 400); 
        }
    }
    /**
    * @param $userId
    * @return \Illuminate\Http\JsonResponse
    */
   public function getEvents($userid) {
        $result = $my_events = $other_events = array();
        if ($userid) {
            /*Getting required data*/
            $result = Chat::where("organizerid", $userid)->orwhere("vendorid", $userid)->orderby('timestamp')->get();
            if (count($result)) {
                foreach ($result as $res) {
                    $temp = array(
                        'id' => $res['id'],
                        'vendorid' => $res['vendorid'],
                        'organizerid' => $res['organizerid'],
                        'eventid' => $res['eventid'],
                        'reqstatus' => $res['reqstatus'],
                        'timestamp' => $res['timestamp']
                    );
                    if($res['organizerid'] == $userid){
                        /*My Events*/
                        $my_events[] = $temp;
                    }
                    else{
                        /* Other Events*/
                        $other_events[] = $temp;
                    }
                    
                    $return_data = array('my_events'=>$my_events, 'other_events'=>$other_events);
                }
                 unset($res);
                 return response()->json(['success' => true, 'message' => "Messages", "code" => 200, "data" => $return_data], 200);
            }
            else{
                 return response()->json(['success' => false, 'message' => "no messages", "code" => 400], 400);
           }
        }
        else{
            return response()->json(['success' => false, 'message' => "no input", "code" => 400], 400); 
        }
    }
    /**
    * @param $userId, $eventid, $message
    * @return \Illuminate\Http\JsonResponse
    */
   public function sendChatRequest(Request $request) {
        $input = $request->all();
        $eventid = $input['eventid'];
	$senderid = $input['userid'];
	$message = $input['message'];
        /* Get event manager ID*/
        $data = Events::select('eventmanager_id')->where('id', $eventid)->get()->toArray();
        $receiverid = $data[0]['eventmanager_id'];
        if($receiverid){
            /* Create Chat ID*/
            $chat_data = Chat::where("eventid", $eventid)
                    ->where("organizerid", $receiverid)
                    ->where("vendorid", $senderid)->get();
            if (!count($chat_data)) {
                Chat::insert(
                    [   'eventid' => $eventid,
                        'vendorid' => $senderid,
                        'organizerid' => $receiverid
                    ]
                );
                $chat_id = DB::getPdo()->lastInsertId();
                if($chat_id > 0){
                    /* Save in messages table*/
                    Messages::insert(
                        [   'chatid' => $chat_id,
                            'senderid' => $senderid,
                            'receiverid' => $receiverid, 
                            'message' => $message
                            ]
                    );
                    $msg_id = DB::getPdo()->lastInsertId();
                    if ($msg_id > 0) {
                         /* Send Notification*/
                        return response()->json(['success' => true, 'message' => "Message added successfully", "code" => 200, "msg_id" => $msg_id], 200);
                    }
                    else{
                        return response()->json(['success' => false, 'message' => "Message not sent", "code" => 400], 400);
                    }
                } /* if chat_id*/
                else{
                    return response()->json(['success' => false, 'message' => "Cannot start Conversation", "code" => 400], 400);
                }
            }/* if $chat_data*/
            else{
                return response()->json(['success' => false, 'message' => "Chat Request Exists", "code" => 400], 400);
            }
        }
        else{
            return response()->json(['success' => false, 'message' => "Event doesnot Exists", "code" => 400], 400);
        }
    }
    /**
    * @param $userid, $chatid,
    * @return \Illuminate\Http\JsonResponse
    */
   public function respondChatRequest(Request $request){
        $input = $request->all();
        $organizerid = $input['userid'];
	$chatid = $input['chatid'];
	$response = $input['response'];
        /* Check if already accepted */
        $data = Chat::select('reqstatus')->where('id', $chatid)->where('organizerid',$organizerid)->get()->toArray();
        if($data){
            $status = $data[0]['reqstatus'];
            if($status == 0){
                $update = Chat::where('id', $chatid)->update(['reqstatus' => $response]);
		if($update){
                    return response()->json(['success' => true, 'message' => "Accepted successfully", "code" => 200], 200);
                }/* if update ends*/
                else{
                    return response()->json(['success' => false, 'message' => "failed to update", "code" => 400], 400);
                }
            }/* if status 0 ends*/
            else{
                return response()->json(['success' => false, 'message' => "approved status", "code" => 400], 400);
            }
        } /* If record exists ends */
        else{
            return response()->json(['success' => false, 'message' => "Invalid Entry", "code" => 400], 400);
        }
    }
    /**
    * @param $userId
    * @return \Illuminate\Http\JsonResponse
    */
   public function getChats($userid, $eventid) {
        $result = $my_events = $other_events = array();
        if ($userid && $eventid) {
            /*Getting required data*/
            $result = Chat::where("eventid", $eventid)->where("organizerid", $userid)->orwhere("vendorid", $userid)->orderby('timestamp')->get();
            if (count($result)) {
                foreach ($result as $res) {
                    $temp = array(
                        'id' => $res['id'],
                        'vendorid' => $res['vendorid'],
                        'organizerid' => $res['organizerid'],
                        'eventid' => $res['eventid'],
                        'reqstatus' => $res['reqstatus'],
                        'timestamp' => $res['timestamp']
                    );
                    $my_events[] = $temp;
                    $return_data = $my_events;
                }
                 unset($res);
                 return response()->json(['success' => true, 'message' => "Messages", "code" => 200, "data" => $return_data], 200);
            }
            else{
                 return response()->json(['success' => false, 'message' => "no messages", "code" => 400], 400);
           }
        }
        else{
            return response()->json(['success' => false, 'message' => "no input", "code" => 400], 400); 
        }
    }
    /**
    * @param $userid, $chatid, $message
    * @return \Illuminate\Http\JsonResponse
    */
   public function setFavChat(Request $request) {
        $input = $request->all();
        $userid = $input['userid'];
	$chatid = $input['chatid'];
        /* Check if already accepted */
        $data = Chat::select('isfav_organizer','isfav_vendor', 'organizerid', 'vendorid')->where('id', $chatid)->where('organizerid',$userid)->orwhere('vendorid',$userid)->get()->toArray();
        if($data){
            $isfav_organizer = $data[0]['isfav_organizer'];
            $isfav_vendor = $data[0]['isfav_vendor'];
            $organizerid = $data[0]['organizerid'];
            $vendorid = $data[0]['vendorid'];
            if($organizerid == $userid){
                $col = 'isfav_organizer';
                if($isfav_organizer == '1'){
                    $value = '0';
                }
                else{
                    $value = '1';
                }
            }
            else if($vendorid == $userid){
                $col = 'isfav_vendor';
                if($isfav_vendor == '1'){
                    $value = '0';
                }
                else{
                    $value = '1';
                }
            }
            if(!empty($col)){
                $update = Chat::where('id', $chatid)->update([$col => $value]);
                if($update){
                    return response()->json(['success' => true, 'message' => "Set successfully", "code" => 200], 200);
                }/* if update ends*/
                else{
                    return response()->json(['success' => false, 'message' => "failed to update", "code" => 400], 400);
                }
            }
            else{
               return response()->json(['success' => false, 'message' => "Invalid Request", "code" => 400], 400);

            }
        } /* If record exists ends */
        else{
            return response()->json(['success' => false, 'message' => "Invalid Entry", "code" => 400], 400);
        }
    }
    /**
    * @param $userId
    * @return \Illuminate\Http\JsonResponse
    */
   public function getFavChats(Request $request) {
        $input = $request->all();
        $eventid = $input['eventid'];
	$senderid = $input['userid'];
        $result = array();
        
    }
}
