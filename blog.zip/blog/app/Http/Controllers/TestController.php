<?php

namespace App\Http\Controllers;
use App\Helpers\MobileApi;
use Illuminate\Http\Request;

class TestController extends Controller
{
   use MobileApi;
   
   function call_trait_from_controller(){
       echo $this->test();exit;
   }
}
