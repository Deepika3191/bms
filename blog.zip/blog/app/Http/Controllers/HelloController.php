<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HelloController extends Controller
{
    
	public function index(){

	$_names=array("a","b","c");

return view('hello',compact('_names')); 
				
	}
	
}
