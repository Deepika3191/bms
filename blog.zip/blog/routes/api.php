<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


//Route::post('chat/index','ChatController@index');
Route::post('chat/sendMessage','ChatController@sendMessage');
Route::get('chat/getMessages/{userid}/{chatid}', 'ChatController@getMessages');
Route::get('chat/getEvents/{userid}', 'ChatController@getEvents');
Route::get('chat/getChats/{userid}/{eventid}', 'ChatController@getChats'); //pending
Route::post('chat/sendChatRequest', 'ChatController@sendChatRequest');
Route::post('chat/respondChatRequest', 'ChatController@respondChatRequest');
Route::post('chat/setFavChat', 'ChatController@setFavChat');
Route::post('chat/getFavChats', 'ChatController@getFavChats');






